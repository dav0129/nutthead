<!--
    PEOPLE.md: A document describing the people behind phpMussel.

    THE TEAM:

    Caleb Mazalevskis.
        Primary role: Project creator and developer.
        GitHub: https://github.com/Maikuolan

    Daniel Ruf.
        Primary role: Developer.
        GitHub: https://github.com/DanielRuf
        Website: https://daniel-ruf.de/

    Matthias Kaschubowski.
        Primary role: Developer.
        GitHub: https://github.com/nhlm
        Website: https://nhlm.eu/




    BELOW THIS LINE IS THE MARKDOWN VERSION OF THIS DOCUMENT. -->

## __The team:__

- __Caleb Mazalevskis__ ([__Maikuolan__](https://github.com/Maikuolan)) - *Project creator and developer.*
- __Daniel Ruf__ ([__DanielRuf__](https://github.com/DanielRuf)) - *Developer.*
- __Matthias Kaschubowski__ ([__nhlm__](https://github.com/nhlm)) - *Developer.*

### __See also:__
- [github.com/orgs/phpMussel/people](https://github.com/orgs/phpMussel/people).

---

*Last modified: 15 August 2017 (2017.08.15).*
